import { Component, ViewChild  } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import {HttpClient}  from "@angular/common/http";
import { TotalPage } from "../total/total";

@Component({
  selector: 'page-try',
  templateUrl: 'try.html',
})
export class TryPage {

  data = Array.apply(null, Array());
  currentData:Info;
  currentIndex = 0;
  items = 1;
  score: number;
  val: any;

  constructor(public navCtrl: NavController, public navParams: NavParams,private http: HttpClient) {
    this.getEnglish();
    this.score = 0;
    this.answer;
  }

  answer(answer: any, correct: any){
    
    if(answer==correct){
      this.val = 'right';
    }else{
      this.val = 'wrong';
    }

  }


  getEnglish(){
    this.http.get<data[]>('http://localhost/let/api/try.php').subscribe((successData) => {
        console.log(successData)
        successData.forEach(element => {
          this.data.push({
            gchoices: element.gchoices.split(","),
            gname:element.gname,
            gquestions:element.gquestions,
            grcno:element.grcno,
            greference:element.greference,
            gsub:element.gsub,
            ganswer:element.ganswer
          });  
        });
        this.currentData = this.data[this.currentIndex];
        console.log(this.currentData)

    }, (error) => console.log(error))
  }

  next(){

      this.items = this.items + 1;

      if(this.val==='right'){
        this.score = this.score + 1;
      }else{
        this.score = this.score + 0;
      }
  
      this.val = '';
  
      this.currentIndex++;
      this.currentData = this.data[this.currentIndex]
  
      if(this.data[this.currentIndex] === undefined){

        this.navCtrl.setRoot(TotalPage, { totalscore : this.score, items: this.items });

      }
  

  }
}

interface data{
  gchoices:string,
  gname:string,
  gquestions:string,
  grcno:number,
  greference:number,
  gsub:string,
  ganswer:number
}
interface Info{
  gchoices:string,
  gname:string,
  gquestions:string,
  grcno:number,
  greference:number,
  gsub:string,
  ganswer:number
}
